import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialize Google GenAI client to prevent crash if key is missing during startup
let aiClient: GoogleGenAI | null = null;
function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is not defined.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// Check key exists API endpoint
app.get("/api/config", (req, res) => {
  res.json({
    hasApiKey: !!process.env.GEMINI_API_KEY,
  });
});

// Proxy Gemini API route
app.post("/api/chat", async (req, res) => {
  try {
    const { messages, systemInstruction, temperature, model, grounding } = req.body;

    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: "Messages array is required." });
    }

    const ai = getAiClient();

    // Map conversation messages to Gemini contents structure
    const contents = messages.map((msg: any) => ({
      role: msg.role === "assistant" ? "model" : "user",
      parts: [{ text: msg.content }]
    }));

    // Build model config
    const config: any = {
      systemInstruction: systemInstruction || "You are a helpful AI Assistant in the Command Center.",
    };

    if (temperature !== undefined) {
      config.temperature = Number(temperature);
    }

    if (grounding) {
      config.tools = [{ googleSearch: {} }];
    }

    const chosenModel = model || "gemini-3.5-flash";

    const response = await ai.models.generateContent({
      model: chosenModel,
      contents,
      config,
    });

    const text = response.text || "";

    // Extract grounding sources search URLs if available
    const groundingMetadata = response.candidates?.[0]?.groundingMetadata;
    const sources = groundingMetadata?.groundingChunks
      ? groundingMetadata.groundingChunks
          .map((c: any) => ({
            title: c.web?.title || c.web?.uri || "Web Grounding Source",
            uri: c.web?.uri || "",
          }))
          .filter((s: any) => s.uri)
      : [];

    res.json({
      content: text,
      sources,
    });
  } catch (error: any) {
    console.error("Gemini API server proxy error:", error);
    res.status(500).json({
      error: error.message || "An unexpected error occurred during the assistant query.",
    });
  }
});

// Dynamic mounting: Serve Vite in dev or static files in production
async function start() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Middlewares: Active (Vite Dev Server Proxy)");
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Serving static files from:", distPath);
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Command Center Server live at http://0.0.0.0:${PORT}`);
  });
}

start().catch((err) => {
  console.error("Failed to start server:", err);
});
